# 画像データ


---

## Pixabayの画像

* [Pixabay](https://pixabay.com/)

* [Pixabay License](https://pixabay.com/service/license/)

### hero.jpg
https://pixabay.com/photos/3196481

### office.jpg
https://pixabay.com/photos/4119674

### manage.jpg
https://pixabay.com/photos/2077020

### reseearch.jpg
https://pixabay.com/photos/3498582



---

## SNSのロゴ画像

* 詳しくは各社のページを参照してください。

### logo-twitter.svg
https://about.twitter.com/ja/company/brand-resources.html

### logo-facebook.svg
https://ja.facebookbrand.com/facebookapp/assets/%E3%80%8Cf%E3%80%8D%E3%83%AD%E3%82%B4/

### logo-instagram.svg
https://en.instagram-brand.com/assets/icons


---

## その他の画像

* エビスコムが作成した画像です。
* README.txtの画像データ以外のライセンスに準拠するものとします。


### bb.svg

### bb-white.svg

### bb.png

### hero.svg
